/** darik radio library scripts	2.0.00 2015-04-20
 	AIP Solutions Ltd'2015 http://aip.solutions
*/
if(!dl.hash)
	dl.hash = function(key, val){
		//alert('dl.hash: '+key+' = '+val);
		if(!key) return false;
		var res = dl.w.encodeURIComponent(val) || '';
		var hash = dl.l.hash;
		var query = {};
		if(!hash || hash == '' || hash == '#')
			query[key] = res;
		else {
			var arr = hash.split('&');
			for(var i in arr) {
				var el = arr[i];
				var sub = el.split('=');
				if(sub[0].indexOf('#') === 0) 
					sub[0] = sub[0].substr(1);
				query[sub[0]] = sub[1];
			}
			if(val !== undefined)
				query[key] = res;
		}
		if(val !== undefined) {
			var ohash = [];
			for(var i in query)
				ohash.push(i+'='+query[i]);
			dl.l.hash = '#'+ohash.join('&');
		} else
			return dl.w.decodeURIComponent(query[key]);
	}
if(!dl.cache)
	dl.cache = {};
/* popup component */
dl.popup=function(url,conf){
	if(!(this instanceof dl.popup))
		return new dl.popup(url,conf);
	if(!conf) conf={};
	this.id=conf.id||'popup';
	this.cls=conf.cls||this.id;
	this.el=dl.el(this.id,{id:this.id,cls:this.cls,tag:'IFRAME'});
	this.close();
	if(url)
		this.open(url);
	dl.w.popup=this; //static registration
}
dl.Popup=dl.popup.prototype;
dl.Popup.open=function(url){
	var self=this;
	this.el.src=url;
	this.el.center=function(){
		var w=this.w||this.offsetWidth;
		var h=this.h||this.offsetHeight;
		this.css('left', Math.max(10,(dl.width()-w)/2)+'px');
		this.css('top', Math.max(10,(dl.height()-h)/2.5)+dl.scroll()+'px');
	}
	this.el.adjust=function(){
		var self=this;
		var body=this.contentDocument.getElementsByTagName('body')[0];
		if(this.h&&this.h==body.offsetHeight) return;
		this.h=(body)? body.offsetHeight : 0;
		this.css('height',this.h+'px');
		this.center(null, this.h);
		setTimeout(function(){self.adjust()}, 100)
	}
	this.el.show();
	this.el.focus();
	this.el.center();
	this.el.on('load', function(){
		this.adjust()
		this.active=true;
	})
	//sugar
	dl.on('resize', function(){self.el.center()})
	//dl.on('scroll', function(){self.el.center()})
	dl.on('click', function(e){
		if(e.target&&e.target!==self.el)
			if(self.el.active) self.close();
	})
}
dl.Popup.close=function(){
	this.el.innerHTML='';
	this.el.hide();
	this.el.h=0;
	this.el.active=false;
}
/* lazy image loading */
dl.lazysrc={state:'idle',wait:1000}
dl.lazysrc.update=function(){
	//trace('dl.dynlist.update: '+this.state);
	if(this.state == 'idle')
		this.process();
	if(this.state == 'wait')
		this.state = 'todo';
	//not need to do anything if alredy in state 'todo'
}
dl.lazysrc.process=function(){
	//trace('dl.dynlist.process: '+this.state);
	this.delay();
	var list = dl.list('img[data-lazysrc]');
	var vh = dl.height();
	for(var i in list) {
		var el = list[i];
		if(!el.dataset || !el.dataset.lazysrc) continue;
		//if in view loads it and removes it from the search
		var y = el.getBoundingClientRect().top;
		if(y > -200 && y < vh + 500) {
			el.src = el.dataset.lazysrc;
			el.removeAttribute('data-lazysrc');
		}
	}
}
dl.lazysrc.delay=function(){
	this.state = 'wait';
	setTimeout(this.ready.bind(this), this.wait);
}
dl.lazysrc.ready=function(){
	if(this.state == 'todo')
		this.process();
	else
		this.state = 'idle';
}
/* image enlarge class */
dl.cache.enlarge=[];
dl.enlarge=function(id){
	var id = id||'enlarge.0';
	if(dl.cache.enlarge[id]) //cache lookup
		return dl.cache.enlarge[id];
	if(!(this instanceof dl.enlarge)) //auto object creation
		return dl.cache.enlarge[id] = new dl.enlarge(id);
	//finally the class can start :)
	this.id = id;
	var list = dl.list('img[data-enlarge-src]');
	if(list.length) {
		//create the big container
		this.cont = dl.el('enlarge.cont', { cls:'enlarge',
			//mss 2015-05-11, bcs Safari: css:{display:'none', opacity:'0.01', overflow:'hidden', top:dl.height()/4+dl.scroll(), left:dl.width()/4, width:dl.width()/2, height:dl.height()/2},
			css:{display:'none', opacity:'0.01', top:dl.height()/4+dl.scroll(), left:dl.width()/4, width:dl.width()/2, height:dl.height()/2},
		});
		this.src = new Image();
		this.img = dl.el('enlarge.img', {tag:'IMG', parent:this.cont});
		this.alt = dl.el('enlarge.alt', {tag:'IMG', parent:this.cont});
		this.info = dl.el('enlarge.info', {tag:'DIV', parent:this.cont});
		this.title = dl.el('enlarge.title', {tag:'H3', parent:this.info});
		this.text = dl.el('enlarge.text', {tag:'P', parent:this.info});
		this.hide = dl.el('enlarge.hide', {tag:'A', cls:'hide', parent:this.cont});
		this.hide.on('click', this.close.bind(this))
		this.prev = dl.el('enlarge.prev', {tag:'A', cls:'prev', parent:this.cont});
		this.prev.on('click', this.open.bind(this, this.prev))
		this.next = dl.el('enlarge.next', {tag:'A', cls:'next', parent:this.cont});
		this.next.on('click', this.open.bind(this, this.next))
		//initialize the elements
		this.list=[];
		this.hint={};
		for(var i in list) {
			var el = dl.el(list[i]);
			var src = el.data('enlargeSrc');
			if(src) {
				this.list.push(src);
				this.hint[src] = {hint:el.title || el.alt, title:el.data('enlargeTitle'), text: el.data('enlargeText')}
				el.on('click', this.open.bind(this, src));
				el.css('cursor', 'zoom-in');
			}
		}
		//trace(this.hint);
		//close when clicked outside
		var self = this;
		dl.on('click', function(e){
			if(!e.target || !e.target.parentNode) return true;
			if(e.target.dataset['enlargeSrc']) return true;
			if(e.target.parentNode != self.cont)
				self.close();
		})
		dl.on('resize', this.adjust.bind(this));
	}
}
dl.Enlarge = dl.enlarge.prototype;
dl.Enlarge.open = function(src){
	if(typeof src == 'object')
		src = src.data('src');
	if(!src) return false;
	//reset main container
	//change the source
	this.src.src = src;
	this.img.src = src;
	this.img.on('load', this.adjust.bind(this));
	//reset size
	this.img.w = this.img.h = 0;
	//adjust size and position
	this.adjust();
	//set the title
	if(this.hint[src]) {
		this.title.html(this.hint[src]['title']||'');
		this.text.html(this.hint[src]['text']||'');
	} else {
		this.title.html('');
		this.text.html('');
	}
	//handle the links
	var i = this.list.indexOf(src);
	var prev = (i<1)? this.list.length-1 : i-1;
	var next = (i>this.list.length-2)? 0 : i+1;
	this.prev.dataset.src = this.list[prev];
	this.next.dataset.src = this.list[next];
	//show the container
	this.cont.show().css('opacity', '0.99', 100);
	this.timer = null;
}
dl.Enlarge.close = function(){
	this.cont.css('opacity', '0.01').hide();
	this.img.src = "";
}
dl.Enlarge.adjust = function(){
	var img = {w:this.src.width, h:this.src.height};
	if(img.w!=this.img.w||img.h!=this.img.h) { //wait if not ready
		if(!this.timer) {
			var self = this;
			this.timer = setTimeout(function(){
				self.adjust();
				self.timer=null;
			}, 100);
		}
		if(!img.w||!img.h)	return false;
	}
	this.img.w = img.w;
	this.img.h = img.h;
	var win = {w:dl.width()-20, h:dl.height()-10};
	//check if image larger than window
	if(img.w > win.w || img.h > win.h) {
		img.k = img.w / img.h;
		win.k = win.w / win.h;
		if(img.k > win.k) { //resize horizontally
			img.w = win.w
			img.h = img.w / img.k;
		} else {
			img.h = win.h
			img.w = img.h * img.k;
		}
	}
	var cnt = {
		l:Math.max((win.w-img.w)/2, 1),
		t:Math.max((win.h-img.h)/2+dl.scroll(), 1),
		w:img.w,
		h:img.h,
	}
	this.img.css({width:img.w, height:img.h});
	this.cont.css({left:cnt.l, top:cnt.t, width:cnt.w, height:cnt.h});
}
//static execution
dl.lazy = function(){
	dl.lazysrc.update();
}
/* sticky menu */
dl.sticky=function(){
	var list = dl.list('[data-sticky]');
	for(var i in list) {
		var el = dl.el(list[i]);
		var val = el.data('sticky') || el.offsetHeight;
		if(dl.scroll() > val)
	    	el.add('sticky');
	  	else
			el.remove('sticky');
	}
}
dl.pad = function(a,b){return(1e15+a+"").slice(-b)}
dl.sec2time = function(sec){
	var sec = Math.round(sec);
	var h = Math.floor(sec/3600);
	var m = Math.floor((sec%3600)/60);
	var s = Math.floor(sec%60);
	return dl.pad(h, 2)+':'+dl.pad(m, 2)+':'+dl.pad(s, 2);
}
/* custom code for darik */
aip = {is:{}}
//homepage feature swap
aip.feature=function(id){
	if(!(this instanceof aip.feature))
		return new aip.feature(id);
	this.id = id;
	this.active = this.id+'.default';
	this.init();
}
aip.Feature=aip.feature.prototype;
aip.Feature.init=function(){
	var list = dl.el(this.id).list('article[data-img]');
	var main = dl.el(this.id+'.main');
	for(var i = list.length;i--;) {
		var id = list[i].id;
		var el = dl.el(list[i]);
		var nel = el.cloneNode(el);
			nel.id = id+'.main';
		var div = dl.el(id+'.div', {tag:'DIV', parent:null});
		nel.insertBefore(div, nel.firstChild);
		main.appendChild(nel);
		var img = dl.el(id+'.img', {tag:'IMG', parent:dl.el(id+'.div'), src:el.data('img')});
		el.on('mouseover', this.over.bind(this, id));
	}
	dl.el(dl.el(this.id).parentNode).on('mouseleave', this.out.bind(this));
}
aip.Feature.over=function(id){
	this.swap(id);
}
aip.Feature.out=function(e){
	this.swap(this.id+'.default');
}
aip.Feature.swap=function(id){
	if(!dl.is.tablet) return false;
	if(this.active) {
		dl.el(this.active).remove('active');
		dl.el(this.active+'.main').remove('active');
	}
	this.active = id;
	dl.el(this.active).add('active');
	dl.el(this.active+'.main').add('active');
	//var h = dl.el(this.active+'.main').offsetHeight;
	//if(h > 450)
	//	dl.el(this.id+'.main').css('height', h);
}
//homepage categories swap
aip.category=function(id){
	if(!(this instanceof aip.category))
		return new aip.category(id);
	this.id = id;
	this.el = null;
	this.active = false;
	this.init();
}
aip.Category=aip.category.prototype;
aip.Category.init=function(){
	this.el = dl.el(this.id);
	var list = this.el.list('article[data-img]');
	for(var i = list.length;i--;) {
		var id = list[i].id;
		var el = dl.el(list[i]);
		if(el.classList.contains('active'))
			this.active = id;
		if(!dl.is.el(id+'.img')){
			dl.el(id+'.div', {tag:'DIV', parent:dl.el(this.id+'.main'), cls:el.className});
			dl.el(id+'.img', {tag:'IMG', parent:dl.el(id+'.div'), src:el.data('img'), onclick:el.attr('onclick')});
		}
		dl.el(id).on('mouseover', this.over.bind(this, id));
	}
}
aip.Category.over=function(id){
	if(!dl.is.tablet) return false;
	if(this.active) {
		dl.el(this.active).remove('active');
		dl.el(this.active+'.div').remove('active');
	}
	this.active = id;
	dl.el(this.active).add('active');
	dl.el(this.active+'.div').add('active');
}
//radio.map
aip.map=function(id){
	if(!(this instanceof aip.map))
		return new aip.map(id);
	this.id = id || 'map';
	this.active = false;
	this.list = {};
	this.listc ={};
	this.init();
}
aip.Map=aip.map.prototype;
aip.Map.init=function(){
	//Radios
	var list = dl.el(this.id).childNodes;
	for(var i=list.length;i--;) {
		var el = list[i];
		if(el.tagName == 'image') {
			el = dl.el(el);
			el.add('map-image');
			el.on('mouseover', function(){
				this.style.cursor = 'pointer';
				dl.el('map.popup').remove('active');
			});
			var key = el.id.replace('.image', '');
			var lel = dl.el(key+'.label');
				lel.add('map-label');
			el.on('click', function(){
				dl.url(lel.getAttribute('href'));
			});
			this.list[key] = el;
		}
	}
	dl.on('resize', this.pos.bind(this));
	//Towers
	var list = dl.el('Towers').childNodes;
	for(var i=list.length;i--;) {
		var el = list[i];
			el.onmouseover = function(){
				var map = dl.el('map').getBoundingClientRect();
				var pos = this.getBoundingClientRect();
				var html = '<b>' + (this.getAttribute('city') || '') + '</b>' + (this.getAttribute('tower') || '');
				dl.el('map.popup').html(html).css({left:pos.left-map.left+24, top:pos.top-map.top+2}).add('active');
			};
			//el.onmouseout = function(){
			//	dl.el('map.popup').remove('active');
			//};
	}
	dl.el('map').on('mouseleave', this.out.bind(this));
	//cities
	var list = dl.el('Cities').childNodes;
	for(var i=list.length;i--;) {
		var el = list[i];
		if(el.tagName != 'image') continue;
		var key = el.id.replace('.image', '');
		var html = '<b>' + (el.getAttribute('city') || '') + '</b>' + (el.getAttribute('freq') || '');
		dl.el(key+'.label',{tag:'A', cls:'map-label map-transp', parent:dl.el('map')}).html(html);
		this.list[key] = el;
	}
	this.pos();
}
aip.Map.pos = function(){
	var map = dl.el('map').getBoundingClientRect();
	for(var i in this.list) {
		var el = this.list[i];
		var pos = el.getBoundingClientRect();
		dl.el(i+'.label').css({left:pos.left-map.left+24, top:pos.top-map.top});
	}
	for(var i in this.listc) {
		var el = this.listc[i];
		if(el.tagName != 'image') continue;
		var pos = el.getBoundingClientRect();
		dl.el(i+'.label').css({left:pos.left-map.left, top:pos.top-map.top});
	}
}
aip.Map.out = function(){
	dl.el('map.popup').remove('active');
}
//author filter
aip.is.author=[];
aip.author=function(id){
	if(aip.is.author[id])
		return aip.is.author[id];
	if(!(this instanceof aip.author))
		return new aip.author(id);
	this.id = id || 'author';
	this.link = null;
	this.letter = null;
	this.init();
	aip.is.author[id] = this;
}
aip.Author=aip.author.prototype;
aip.Author.init=function(){
	this.list = dl.list('a[data-link]');
	this.letter = dl.list('article[data-letter]');
	for(var i=this.list.length;i--;) {
		var el = dl.el(this.list[i]);
		if(this.check(el.data('link'))) {
			el.add('link');
			el.on('click', this.filter.bind(this, el.data('link')));
		}
	}
}
aip.Author.filter=function(letter){
	this.clear();
	dl.el(this.id+'.'+letter+'.link').add('active');
	for(var i=this.letter.length;i--;) {
		var el = dl.el(this.letter[i]);
		if(!letter || el.data('letter') == letter)
			el.show('block', [400,500]);
	}
}
aip.Author.check=function(letter){
	for(var i=this.letter.length;i--;)
		if(dl.el(this.letter[i]).data('letter') == letter)
			return true;
	return false;
}
aip.Author.clear=function(){
	for(var i=this.list.length;i--;)
		dl.el(this.list[i]).remove('active');
	for(var i=this.letter.length;i--;)
		dl.el(this.letter[i]).hide(400);
}
//show filter
aip.is.show=[];
aip.show=function(id){
	if(aip.is.show[id])
		return aip.is.show[id];
	if(!(this instanceof aip.show))
		return new aip.show(id);
	this.id = id || 'show';
	this.link = null;
	this.letter = null;
	this.init();
	aip.is.show[id] = this;
}
aip.Show=aip.show.prototype;
aip.Show.init=function(){
	this.list = dl.list('a[data-link]');
	this.letter = dl.list('article[data-letter]');
	for(var i=this.list.length;i--;) {
		var el = dl.el(this.list[i]);
		if(this.check(el.data('link'))) {
			el.add('link');
			el.on('click', this.filter.bind(this, el.data('link')));
		}
	}
}
aip.Show.filter=function(letter){
	this.clear();
	dl.el(this.id+'.'+letter+'.link').add('active');
	for(var i=this.letter.length;i--;) {
		var el = dl.el(this.letter[i]);
		if(!letter || el.data('letter') == letter)
			el.show('block', [400,500]);
	}
}
aip.Show.check=function(letter){
	for(var i=this.letter.length;i--;)
		if(dl.el(this.letter[i]).data('letter') == letter)
			return true;
	return false;
}
aip.Show.clear=function(){
	for(var i=this.list.length;i--;)
		dl.el(this.list[i]).remove('active');
	for(var i=this.letter.length;i--;)
		dl.el(this.letter[i]).hide(400);
}
//audio player
aip.is.player=[];
aip.player=function(id){
	if(aip.is.player[id])
		return aip.is.player[id];
	if(!(this instanceof aip.player))
		return new aip.player(id);
	this.id = id || 'player';
	this.el = null;			//main container
	this.audio = null;		//audio tag
	this.button = null;		//play/pause button
	this.bar = null;		//progress bar
	this.tip = null;		//tooltip
	this.meter = null;		//progress indicator
	this.time = null;		//total/elapsed time indicator
	this.state = '';		//state machine
	this.init();
	aip.is.player[id] = this;
}
aip.Player=aip.player.prototype;
aip.Player.init=function(){
	if(!dl.is.el(this.id)) return false;
	this.el = dl.el(this.id);
	this.audio = dl.el(this.el.list('audio')[0]);
	this.button = dl.el(this.el.list('a')[0]);
	this.bar = dl.el(this.el.list('div')[0]);
	this.tip = dl.el(this.el.list('b')[0]);
	this.meter = dl.el(this.el.list('div > q')[0]);
	this.time = dl.el(this.el.list('span')[0]);
	if(this.audio)
		this.bind();
  	this.update();
}
aip.Player.bind=function(){
	var self = this;
	this.button.on('click', function(){
		if(self.state == 'play')
			self.pause();
		else 
		if(self.state == 'ready' || self.state == 'pause')
			self.play();
	});
	this.bar.on('click', function(e){
		if(e.target.tagName == 'Q')
			self.seek((e.layerX - e.target.parentNode.offsetLeft)/e.target.parentNode.offsetWidth);
		else
			self.seek((e.layerX - e.target.offsetLeft)/e.target.offsetWidth);
	});
	this.bar.on('mouseover', function(e){
		self.tip.show();
	});
	this.bar.on('mousemove', function(e){
		var r = (e.layerX - e.target.offsetLeft)/e.target.offsetWidth;
		if(e.target.tagName == 'Q') {
			var k = (e.target.offsetWidth / e.target.parentNode.offsetWidth).toFixed(3);
			if(k > 0) r*=k;
		}
		var d = self.audio.duration;
		var t = dl.sec2time(d * r);
		if(d < 3600)
			t = t.slice(3);
		self.tip.css('left', e.layerX).html(t);
	});
	this.bar.on('mouseout', function(e){
		self.tip.hide();
	});
	this.audio.on('canplay', this.canplay.bind(this))
	this.audio.on('waiting', this.waiting.bind(this))
	this.audio.on('timeupdate', this.update.bind(this))
	this.state = 'ready';
}
aip.Player.waiting=function(){
	this.button.data('cls', this.button.className);
	this.button.className = 'waiting';
}
aip.Player.canplay=function(){
	this.button.className = this.button.data('cls') || 'player';
	this.update();
}
aip.Player.update=function(){
	var time = this.audio.currentTime || 0;
	var durr = this.audio.duration || 0;
	//time readings
	var timef = dl.sec2time(time);
 	var durrf = dl.sec2time(durr);
	if(durr < 3600) {
		timef = timef.slice(3);
		durrf = durrf.slice(3);
	}
  	this.time.html(timef+' | '+durrf);
    //progress bar
    var progress = (time/durr*100).toFixed(1);
    this.meter.style.width = progress+'%';
	if(this.audio.ended) {
		this.state = 'ready';
		this.button.className = 'player';
	}
}
aip.Player.play=function(){
	if(this.audio.data('src'))
		this.audio.src = this.audio.data('src');
	this.audio.play();
	this.state = 'play';
	this.button.className = 'play';
}
aip.Player.pause=function(){
	this.audio.pause();
	this.state = 'pause';
	this.button.className = 'pause';
}
aip.Player.stop=function(){
	this.audio.stop();
	this.audio.currentTime = 0;
	this.state = 'ready';
	this.button.className = '';
}
aip.Player.seek=function(r){
	this.audio.currentTime = Math.round(this.audio.duration * r);
	this.update();
}
//dynamic list loader
aip.is.list={};
aip.list=function(id){
	if(aip.is.list[id])
		return aip.is.list[id];
	if(!(this instanceof aip.list))
		return new aip.list(id);
	this.id = id || 'list';
	this.el = null;		//main container
	this.url = '';		//page url
	this.qry = '';		//qyery string
	this.more = '';		//if more results are required
	this.page = 0;		//page count
	this.state = '';	//state machine
	this.parent = '';	//parent content
	this.lastpos = 0;	//last scroll position to detect scroll direction
	this.init();
	if(this.state == 'ready')
		this.load()
	aip.is.list[this.id] = this;
}
aip.List=aip.list.prototype;
aip.List.init=function(){
	this.el = dl.el(this.id);		//main container
	this.url = this.el.data('url') || dl.l.pathname.replace('.html', '.'+id+'.ajax.php');
	this.page = dl.hash('page') || 0;
	this.more = this.el.data('more')? true : false;
	this.parent = this.el.data('parent');
	this.lastpos = dl.scroll();
	this.bind();
	this.state = 'ready';
}
aip.List.bind=function(){
	dl.on('hashchange', this.load.bind(this));
	dl.on('scroll', this.scroll.bind(this));
}
aip.List.load=function(){
	if(this.state != 'ready') return false;
	var self = this;
	this.state = 'busy';
	this.page = +dl.hash('page');
	if(this.parent)
		dl.hash('parent', this.parent);
	this.qry = dl.l.hash.replace('#', '?');
	this.el.add('loading');
	//selects the appropriate selects
	this.active('show');
	this.active('category');
	this.active('radio');
	dl.xhr(this.url+this.qry, null, function(data){
		if(self.page > 0)
			self.el.innerHTML+= data;
		else {
			self.el.innerHTML = data;
			dl.w.scrollTo(0,0);
		}
		if(data) {
			if(self.state == 'more') {
				self.state = 'ready';
				dl.hash('page', self.page+1);
			} else 
				self.state = 'ready';
		} else {
			if(self.page)
				dl.hash('page', self.page-1);
			this.state = 'done';
		}
		self.el.remove('loading');
	});
}
aip.List.scroll=function(e){
	var win = dl.height();
	var cnt = this.el.parentNode.offsetHeight;
	if(win > cnt) return false;
	if(this.lastpos > dl.scroll()) return false;
	this.lastpos = dl.scroll();
	var top = this.el.parentNode.offsetHeight-dl.scroll()-dl.height();
	if(top < 0) {
		if(this.state == 'ready')
			dl.hash('page', +this.page+1);
	}
}
aip.List.active=function(id){
	if(!dl.is.el(id+'.select')) return;
	if(dl.hash(id+'Id')) {
		dl.el(id+'.select').add('active');
		dl.el(id+'.select').value = dl.hash(id+'Id');
	} else
		dl.el(id+'.select').remove('active');
}
aip.List.reset=function(){
	this.state = 'ready';
}
//article gallery
aip.is.gallery=[];
aip.gallery=function(id){
	if(aip.is.gallery[id])
		return aip.is.gallery[id];
	if(!(this instanceof aip.gallery))
		return new aip.gallery(id);
	this.id = id;
	this.el = null;
	this.list = [];
	this.cont = null;
	this.active = 0;
	this.init();
}
aip.Gallery=aip.gallery.prototype;
aip.Gallery.init=function(){
	this.el = dl.el(this.id);
	var list = this.el.list('article[data-item]');
	if(!list.length) return false;
	var item = {};
	for(var i = list.length;i--;) {
		var el = dl.el(list[i]);
		item[el.data('item')] = el;
	}
	var list = this.el.list('a[data-link]');
	if(!list.length) return false;
	for(var i = list.length;i--;) {
		var el = {
				link: dl.el(list[i]),
				item: item[i] || false,
				img	: item[i].list('img[data-src]')[0],
			}
			el.img.src = dl.el(el.img).data('src');
		this.list[el.link.data('link')] = el;
	}
	this.cont = dl.el(this.el.list('dt')[0]);
	this.bind();
}
aip.Gallery.bind=function(){
	for(var i in this.list) 
		this.list[i].link.on('click', this.set.bind(this, i));
	//this.cont.on('click', this.next.bind(this));
}
aip.Gallery.set=function(id){
	if(this.active == id) return true;
	var el = null;
	if(this.active !== false) {
		el = this.list[this.active];
		el.link.remove('active');
		el.item.remove('active');
	}
	this.active = id;
	el = this.list[this.active];
	el.link.add('active');
	el.item.add('active');
	//scroll to top of the image
	var pos = this.el.getBoundingClientRect();
	if(pos.top < 0) {
		dl.w.scrollBy(0, pos.top-50);
	}
}
aip.Gallery.next=function(e){
	var px = (e.layerX - e.target.offsetLeft)/e.target.offsetWidth;
	var i = this.active;
	if(px > 0.3) { 
		i++;
		if(i >= this.list.length)
			i = 0;
	} else {
		i--;
		if(i <= 0)
			i = this.list.length - 1;
	}
	this.set(i);
}
//radio.map