// dl.enlarge = function(id) {
//     if (!(this instanceof dl.enlarge))
//         return new dl.enlarge(id);
//     this.id = id || 'enlarge';
//     this.i = false;
//     if (this.init()) this.bind();
// }

// dl.Enlarge = dl.enlarge.prototype;

// dl.Enlarge.init = function() {
//     this.container = dl.el(this.id + '.cont', { cls: 'enlarge' });
//     this.imageList = dl.list('img[data-' + this.id + ']');
//     this.imageElement = dl.el(this.id + '.img', { tag: 'IMG', parent: this.container });
//     this.closeButton = dl.el(this.id + '.hide', { tag: 'A', cls: 'hide', parent: this.container });
//     this.titleElement = dl.el(this.id + '.title', { tag: 'H3', parent: this.container });
//     if (this.imageList.length > 1) {
//         this.prevButton = dl.el(this.id + '.prev', { tag: 'A', cls: 'prev', parent: this.container });
//         this.nextButton = dl.el(this.id + '.next', { tag: 'A', cls: 'next', parent: this.container });
//     }
//     return true;
// }

// dl.Enlarge.bind = function() {
//     this.closeButton.on('click', this.close.bind(this));
//     this.imageElement.on('load', this.load.bind(this));
//     dl.on('resize', this.load.bind(this));
//     for (var i = this.imageList.length; i--; dl.el(this.imageList[i]).on('click', this.open.bind(this, i)).css('cursor', 'zoom-in'));
//     if (this.imageList.length > 1 && dl.is.touch) {
//         dl.on('wipeLeft', this.prev.bind(this));
//         dl.on('wipeRight', this.next.bind(this));
//     }
//     if (this.imageList.length > 1) {
//         this.prevButton.on('click', this.prev.bind(this));
//         this.nextButton.on('click', this.next.bind(this));
//     } else {
//         this.container.on('click', this.close.bind(this));
//     }
// }

// dl.Enlarge.open = function(index, dir) {
//     this.i = index;
//     this.transition(dir);
//     this.imageElement.src = this.imageList[this.i].dataset[this.id];
//     this.container.add('active');
//     if (dl.gesture) dl.gesture.block = 1;
// }

// dl.Enlarge.load = function() {
//     var element = this.imageList[this.i];
//     var image = this.imageElement;
//     if (element)
//         this.titleElement.html(element.alt || element.title).css({ left: '0', bottom: '-' + (image.offsetHeight + 15) + 'px', width: '100%' });
// }

// dl.Enlarge.close = function() {
//     this.i = false;
//     this.imageElement.src = '#';
//     this.container.remove('active');
//     if (dl.gesture) dl.gesture.block = 0;
// }

// dl.Enlarge.prev = function(e) {
//     if (e) e.stopPropagation();
//     this.open(this.i ? this.i - 1 : this.imageList.length - 1, 1);
// }

// dl.Enlarge.next = function(e) {
//     if (e) e.stopPropagation();
//     this.open(this.i < this.imageList.length - 1 ? this.i + 1 : 0, -1);
// }

// dl.Enlarge.transition = function(dir) {
//     var image = this.imageElement;
//     if (image.src == '' || image.src.indexOf('#') != -1) return;
//     var clonedImage = image.cloneNode();
//     dl.el(clonedImage).css({ position: 'absolute', left: '0', top: '0', width: '100%', height: '100%' });
//     image.parentNode.appendChild(clonedImage);
//     if (dir)
//         dl.el(clonedImage).css('left', dir * dl.width());
// }

//----------------------------------------------------------------------------------//
document.addEventListener("DOMContentLoaded", function() {
    
    var images = document.querySelectorAll('.image article img'); // взимаме всички снимки
    var currentIndex = 0; // запазваме индекса на натиснатата снимка

    images.forEach(function(image, index) {
        image.addEventListener("click", function() {
            var enlargedImageOverlay = document.createElement('div');
            enlargedImageOverlay.id = 'enlarged-image-overlay';
            enlargedImageOverlay.style.display = 'flex'; 
            enlargedImageOverlay.style.justifyContent = 'center'; 
            enlargedImageOverlay.style.alignItems = 'center'; 

            var enlargedImageContainer = document.createElement('div');
            enlargedImageContainer.id = 'enlarged-image';
            enlargedImageContainer.style.display = 'flex'; 
            enlargedImageContainer.style.justifyContent = 'center'; 
            enlargedImageContainer.style.alignItems = 'center'; 

            var img = document.createElement('img');
            img.src = image.getAttribute('data-enlarge');
            img.style.width = '65%';
            img.style.height = 'auto';
            img.style.display = 'block';
            img.style.margin = '0';

            enlargedImageContainer.appendChild(img);

            var prevButton = document.createElement('a'); // създава а линк
            prevButton.classList.add('prev');
            prevButton.innerHTML = '<a class="icon prev">&#10094;</a>'; // символчета
            enlargedImageOverlay.appendChild(prevButton);

            var hideButton = document.createElement('a'); // създава а линк
            hideButton.classList.add('hide');
            hideButton.innerHTML = '<a class="icon hide">&#10006;</a>'; // символчета
            enlargedImageOverlay.appendChild(hideButton);

            // Функция за бутона за затваряне на снимката 
            hideButton.addEventListener("click", function(event) {
                console.log("Затворена с a елемента"); // работи !
                //премахване на оголемената снимка
                document.body.removeChild(enlargedImageOverlay); 
                document.body.removeChild(enlargedImageContainer);
            });

            var nextButton = document.createElement('a'); // създава а линк
            nextButton.classList.add('next');
            nextButton.innerHTML = '<a class="icon next">&#10095;</a>'; // символчета 
            enlargedImageOverlay.appendChild(nextButton);

            // Добавяне на EventListener за следваща снимка
            nextButton.addEventListener("click", function(event) {
                currentIndex = (currentIndex + 1) % images.length; // Обновяваме индекса на текущата снимка
                img.src = images[currentIndex].getAttribute('data-enlarge'); // следващата снимка
                console.log("Показана на екрана снимка със индекс ->", currentIndex);
            });

            // Добавяне на EventListener за предишна снимка
            prevButton.addEventListener("click", function(event) {
                currentIndex = (currentIndex - 1 + images.length) % images.length; // Обновяваме индекса на текущата снимка
                img.src = images[currentIndex].getAttribute('data-enlarge'); // предишната снимка
                console.log("Показана на екрана снимка със индекс <-", currentIndex);
            });

            //css - снимка
            document.body.appendChild(enlargedImageOverlay); 
            document.body.appendChild(enlargedImageContainer);

            console.log("Отворена снимка" , index , "- индекс на снимката"); // отчита на клик на снимка / работи !
        });
    });
});

// \\TO DO - first day \\
// Да се направят стрелките и хикса да се показват на екрана като е оголемена снимката - ready !
// Да се доабвят функционалности за предишна снимка следваща снимка и затваряне - ready ! 

// \\ TO DO - second day CSS-only(dl.enlarge.css) \\
//css-a да оправя z-index на изображението и полупорозрачиния background - готово !
//да сменя текста със иконки/шрифт - готово !
// следваща снимка да отиде където му е мястото - готово !
//---------------------КРАЙ--------------------//