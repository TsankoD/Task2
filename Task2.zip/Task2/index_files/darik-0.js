/** ZipShop scripts	2.0.00 2014-11-16
 	AIP Solutions Ltd'2008-2014 http://www.aip.solutions
*/
//onload execution
dl.on('ready', function(e){
	//navigation initialization
	dl.el('menu.btn').on('click', function(e){
		this.toggle('active');
	});
	dl.el('schedule.btn').on('click', function(e){
		this.toggle('active');
	});
	//dynamic lists
	if(dl.is.el('list')) 
		aip.list();
	//loads dynamically the images
	if(dl.lazy)
		dl.lazy();
	//handles sticky menu
	if(dl.sticky)
		dl.sticky();
	//initialize image swap
	if(dl.swap)
		dl.swap();
	//search
	if(dl.is.el('filter.qry'))
		dl.el('filter.qry').on('keyup', function(e){aip.keyfilter(e)})
	//initialize custom classes
	var list = dl.list('[data-aip]');
	for(var i in list) {
		var el = dl.el(list[i]);
		var cls = el.data('aip');
		if(cls && aip[cls])
			aip[cls](el.id);
	}
	//image enlarging
	if(dl.enlarge)
		dl.enlarge();
	//social media include
	dl.include('//connect.facebook.net/bg_BG/sdk.js#xfbml=1&version=v2.4', 'facebook-jssdk');
});
//onresize event handler
dl.on('resize', function(e){
	//loads dynamically the products
	if(dl.lazy)
		dl.lazy();
})
//onmobile switch handler
dl.on('mobile', function(e){
	dl.image('img');
	dl.is.tablet = false;
});
//ontablet switch handler
dl.on('tablet', function(e){
	dl.image('img');
	dl.is.tablet = true;
});
//ondesktop switch handler
dl.on('desktop', function(e){
	dl.image('img');
	dl.is.tablet = true;
});
//onscroll event handler
dl.on('scroll', function(t){
	//loads dynamically the products
	if(dl.lazy)
		dl.lazy();
	//handles sticky menu
	if(dl.sticky)
		dl.sticky();
})
//initialization
dl.response();
//additional classes
aip.load = function(id, item){
	if(aip.is.load) {
		dl.el(aip.is.load).remove('active');
		aip.is.load = null;
	}
	aip.is.load = id+'.'+item+'.'+'link';
		dl.el(aip.is.load).add('active');
	if(dl.is.el(id) && dl.is.el(id+'.cont')) {
		dl.el(id+'.cont').add('loading').load(dl.el(id).data('url')+'?radioId='+item, function(){dl.el(id+'.cont').remove('loading')});
	}
}
aip.filter = function(id){
	if(!id) return false;
	var el = dl.el(id);
	if(el.val()) el.add('active');
	else		 el.remove('active');
	if(aip.is.list['list'])
		aip.is.list['list'].reset();
	dl.hash(el.name, el.value);
	dl.hash('page', 0);
}
aip.keyfilter = function(e){
	if(e.keyCode == 13)
		aip.filter(e.target||e.srcElement);
}
//end of code. enjoy...