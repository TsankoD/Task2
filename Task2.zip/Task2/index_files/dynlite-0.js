/* dynlite javascript library
 * peter assenov- aip solutions ltd' 2001-2014
 * ver 2.4.3 - 2015-08-06
 */
/* main environment */
dl={w:window,d:document,n:navigator,l:location,c:console};
dl.p=dl.w.performance||Date;
dl.is={
	el:function(id){return dl.d.getElementById(id)},
	ready:0,
	touch:('ontouchstart' in window)? 1:0,
}
dl.evt={};
dl.on=function(e,m,cb){
	if(!cb||typeof m=='function') cb=m; //preparation for module prerequisites
	if(e=='load'||e=='ready')
		if(dl.is.ready) return cb();
		else e='DOMContentLoaded';
	else
		dl.evt[e]=cb;
	dl.w.addEventListener(e,cb);
};
/* dom interface */
dl.el=function(id,conf){
	var el=(typeof id=='object')? id : dl.d.getElementById(id) || dl.d.createElement((conf&&conf.tag)||'DIV');
	//main
	el.attr=function(attr, val){
		if(!attr) return false;
		if(!val) return el.getAttribute(attr);
		el.setAttribute(attr, val);
		return this;
	}
	//css
	el.add=function(cls){this.classList.add(cls);return this;}
	el.remove=function(cls){this.classList.remove(cls);return this;}
	el.toggle=function(cls){this.classList.toggle(cls);return this;}
	el.css=function(prop,val,time){
		if(typeof prop=='object')
			for(var i in prop)
				this.css(i,prop[i],val);
		else if(!val && dl.w.getComputedStyle(el)) return dl.w.getComputedStyle(el).getPropertyValue(prop); //GET
		else if(!time) {
			var c = (typeof val=='object')? val[1] : val;
			if("|width|height|left|top|".indexOf('|'+prop+'|') !== -1)
				c = c.toString().replace('px', '')+'px';
			else if(prop == 'opacity' && c == 1)
				c = 0.9999
			this.style[prop] = c; //SET
		} else if(typeof time=='object')
			dl.w.setTimeout(function(){dl.fx.trans(this,prop,val,time[1])}, time[0]);
		else
			dl.fx.trans(this,prop,val,time);
		return this;
	}
	el.show=function(disp, time){
		if(time) {
			var self = this;
			var delay = 1;
			var duration = time;
			if(typeof time === 'object') {
				var delay = time[0];
				var duration = time[1];
			}
			setTimeout(function(){
				self.css('opacity', [0,1], duration);
				self.css('display', disp||'block');
			}, delay);
		} else		
			this.css('display', disp||'block');
		return this;
	}
	el.hide=function(time){
		if(time) {
			var self = this;
			var delay = 0;
			var duration = time;
			if(typeof time === 'object') {
				var delay = time[0];
				var duration = time[1];
			}
			setTimeout(function(){self.css('opacity', [1,0])}, delay);
			setTimeout(function(){self.css('display', 'none')}, delay+duration);
		} else
			this.css('display', 'none');
		return this;
	}
	//events
	el.evt={};
	el.on=function(e,cb){
		if(e=='click' && dl.is.touch) e='touchend';
		if('on'+e in this) 	this.addEventListener(e,cb)
		else			 	this.evt[e]=cb;
		return this;
	}
	el.fire=function(e, p){
		if(this.evt[e]) this.evt[e](p);
		return this;
	}
	//helpers
	el.load=function(url, cb){
		var self=this;
		dl.xhr(url, function(data){self.html(data);if(cb)cb(data)})
		return this;
	}
	el.html=function(html){
		this.innerHTML=html||'';
		return this;
	}
	el.val=function(val){
		if(val===undefined) {
			if(this.tagName=='INPUT') return this.value;
			else if(this.tagName=='SELECT') return this.options[this.options.selectedIndex].value;
			else return this.innerHTML;
		} else
			if(this.tagName=='INPUT' || el.tagName=='SELECT') this.value=val;
			else this.innerHTML=val;
		return this;
	}
	el.data=function(par, val){
		if(typeof par=='object')
			for(var i in par)
				this.data(i,par[i]);
		else 
			if(val!=undefined) this.dataset[par]=val;
			else return this.dataset[par];
		return this;
	}
	el.list=function(qry){ return dl.list(qry, el)}
	// dynamic creation
	if(conf){
		for(var i in conf) {
			var val=conf[i];
			if(i=='cls') el.className=val;
			else if(i=='css'||i=='data'||i=='html') el[i](val);
			else if(i=='tag'||i=='parent') continue;
			else el.setAttribute(i,val);
		}
		if(!el.id) el.id=id;
		if(!el.parentNode && conf.parent !== null) {
			var par=conf.parent||dl.d.body;
				par.appendChild(el);
		}
	}
	return el;
}
dl.list=function(qry,el){return (el||dl.d).querySelectorAll(qry)}
dl.include=function(src,id,cb){
	if(!src) return false;
	if(typeof src=='object')
		for(var i in src)
			dl.include(src[i],i);
	else {
		if(!id||!dl.is.el(id)) {
			var el=dl.d.createElement('script');
				el.src=src;
			if(id) el.id=id;
			if(cb) el.onload=cb;
			dl.d.getElementsByTagName('head')[0].appendChild(el);
		}
	}
	return this;
}
/* http requests */
dl.xhr=function(url,data,cb,hd){
	if(!(this instanceof dl.xhr))
		return new dl.xhr(url,data,cb,hd);
	var self = this;
	this.req=new XMLHttpRequest(); //IE7+
	this.evt={};
	this.data=null;
	this.method='GET';
	this.req.onreadystatechange=function(e){
		if(this.readyState==1) self.do('start', this);
		if(this.readyState==4)
			if(this.status==200) self.do('success', this.response);
			else self.do('error', {'code':this.status, 'text':this.statusText});
	}
	if(url)	dl.w.setTimeout(function(){self.open(url,data,cb)},10);
}
dl.Xhr=dl.xhr.prototype;
dl.Xhr.on=function(e, cb){
	if('on'+e in this.req) this.req.addEventListener(e, cb);
	else this.evt[e]=cb;
}
dl.Xhr.do=function(e, par){
	if(this.evt[e]) this.evt[e](par);
}
dl.Xhr.open=function(url, data, cb, hd){
	if(data) {
		if(!cb && typeof data=='function') cb=data;
		else {
			this.data=(typeof data == 'object')? data : new FormData(dl.el(data));
			this.method='POST';
		}
	}
	this.req.open(this.method, url, true);
	if(hd)
		for(var i in hd)
			this.req.setRequestHeader(i, hd[i]);
	this.req.send(this.data);
	if(cb) this.on('success', cb);
}
/* animations */
dl.fx={run:0, cnt:0, list:[], fps:30} //fps:60/30/15
dl.fx.start=function(){
	if(this.run) return;
	this.cnt=0;
	this.run=parseInt(60/this.fps);
	dl.w.requestAnimationFrame(function(){dl.fx.tick()});
}
dl.fx.stop=function(){this.run=0;}
dl.fx.tick=function(){
	if((++this.cnt%this.run)||this.run==1) {
		var run=0;
		for(var i=this.list.length;i--;)
			if(this.list[i])
				if(this.list[i]()) 	run=1;
				else				this.list[i]=null;
		if(!run)
			this.run=0;
	}
	if(this.run)
		dl.w.requestAnimationFrame(function(){dl.fx.tick()});
}
dl.fx.trans=function(el,prop,val,time,calc){
	if(!(this instanceof dl.fx.trans))
		return new dl.fx.trans(el,prop,val,time,calc);
	var self=this;
	//init
	this.el=(typeof el=="object")? el : dl.el(el);
	this.prop=prop;
	if(typeof val=="object") {
		this.start=+val[0];
		this.end=+val[1];
	} else {
		this.start=+this.el.css(prop).replace('px','');//GET
		this.end=(typeof val == 'number')? val : +val.replace('px','');
	}
	//trace(this.start+'-'+this.end);
	this.time=+time||400;
	this.step=0;
	this.steps=Math.ceil(this.time/1000*dl.fx.fps);
	this.calc=calc||'bezier'; //calc:linear/bezier
	this.vals=dl.fx.calc(this.start,this.end,this.steps,this.calc);
	//start
	dl.fx.list.push(function(){
		if(self.step<=self.steps) {
 			self.el.css(self.prop, self.vals[self.step]);//SET
 			self.step++;
 			return true;
 		} else
			return false;
	})
	dl.fx.start();
}
dl.fx.calc=function(v0,v1,s,c){
	var l=[];
	if(c=='linear'){
		var d=(v1-v0)/s;
		for(var i=s;i--;)
			l[i]=(v0+d*i).toFixed(3);
	} else
	if(c=='bezier'){ //linear bezier ease-out
		for(var i=s;i--;){
			var mu=i/s, mu2=mu*mu, mum1=1-mu, mum12=mum1*mum1;
			l[i]=(v0*mum12+2*v1*mum1*mu+v1*mu2).toFixed(3);
		}
	}
	l.push(v1.toFixed(3));
	return l;
}
/* forms and data storage */
dl.post=dl.xhr;
dl.submit=function(id,url,cb,hd){
	var el=dl.is.el(id)? dl.el(id):dl.d.forms[0];
	if(!url) return el.submit();
	if(!cb&&typeof url=='function'){
		cb=url;url=id;
	}
	dl.xhr(url,id,cb,hd);
}
dl.upload=function(id, url, cb, max){
	if(!id||!url) return false;
	if(!max) max = {w:2000,h:2000}
	var el = (typeof id=='string')? dl.el(id) : id;
	var file = el.files[0];
    var img = dl.is.el(id+'.img')? dl.el(id+'.img') : dl.d.createElement("img");
    var reader = new FileReader();
    reader.onload = function(e){
		img.onload=function(){ //needs delay to populate image size values
     		var k=Math.min(max.w/img.width, max.h/img.height);
      		if(k<1) {img.width*=k;img.height*=k;}
   			var cvs=dl.d.createElement("canvas");
	   		var ctx=cvs.getContext("2d");
			cvs.width=img.width;cvs.height=img.height;
            ctx.drawImage(img,0,0,img.width,img.height);
			var dat=cvs.toDataURL(file.type, 1.0);
			var fd=new FormData();
				fd.append('fn_'+el.name,file.name.toLowerCase().replace('.gif','.png'));
				fd.append('fc_'+el.name,dat);
			dl.submit(fd, url, cb);
    	};
       	img.src = e.target.result;
	}
    reader.readAsDataURL(file);
}
/* application framework */
dl.layout='';
dl.target={'mobile':1024,'tablet':1280,'desktop':1920};
dl.response=function(){
	dl.resize();
	dl.on('resize', dl.resize);
}
dl.resize=function(){
	var w=dl.width(), c=0;
	for(var i in dl.target) {
		if(w<dl.target[i]||i=='desktop') {
			if(dl.layout==i) return;
			else {
				dl.layout=i;
				if(dl.evt[i]) dl.evt[i](w);
				return;
			}
		}
	}
}
dl.width=function(){return dl.w.innerWidth;}
dl.height=function(){return dl.w.innerHeight;}
dl.scroll=function(){return dl.w.scrollY||dl.w.pageYOffset;}
dl.image=function(qry,mode){
	var list=dl.list(qry), mode=mode||dl.layout;
	for(var i in list) {
		var el=list[i];
		if(!el.dataset||!el.dataset.src) continue;
		if(!el.dataset.mobi&&el.src!=el.dataset.src) el.dataset.mobi=el.src;
		el.src=(mode=='mobile')? el.dataset.mobi : el.dataset.src;
	}
}
dl.url=function(url){dl.l.href=url;}
/* benchmark */
dl.cps=-(dl.p.now()-dl.p.now()).toFixed(3);
dl.now=dl.p.now();
dl.gmt=function(){
	var n=dl.p.now(), d=parseInt(n-dl.now);
	dl.now=n;
	return d;
}
/* shortcuts */
trace=console.log.bind(console);
dl.on('ready', function(){dl.is.ready=1})
/* keep the comments and use freely! enjoy... */